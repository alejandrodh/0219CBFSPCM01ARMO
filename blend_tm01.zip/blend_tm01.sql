-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 11-06-2019 a las 13:35:25
-- Versión del servidor: 5.6.38
-- Versión de PHP: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `blend_tm01`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `addresses`
--

CREATE TABLE `addresses` (
  `id` int(10) UNSIGNED NOT NULL,
  `street` varchar(100) NOT NULL,
  `number` smallint(6) NOT NULL,
  `city` varchar(100) NOT NULL,
  `id_usuario` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `excerpt` varchar(255) DEFAULT NULL,
  `content` text,
  `featured_img` varchar(150) DEFAULT NULL,
  `id_usuario` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `posts`
--

INSERT INTO `posts` (`id`, `title`, `excerpt`, `content`, `featured_img`, `id_usuario`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 'El titán loco', 'Historia de un titán', 'The Empire is still out there. I don\'t think it\'s wise to... No time to discuss this as a committee. I am not a committee! You can\'t make the jump to light-speed in this asteroid field... Sit down, sweetheart. We\'re taking off! Look! I see it, I see it. We\'re doomed! The cave is collapsing. This is no cave. What?\r\n\r\nLaugh it up, fuzz ball. But you didn\'t see us alone in the south passage. She expressed her true feelings for me. My...! Why, you stuck up...half-witted...scruffy-looking...nerf-herder! Who\'s scruffy-looking? I must have hit her pretty close to the mark to get her all riled up like that, huh, kid? Why, I guess you don\'t know everything about women yet? Headquarters personnel, report to command center. Take it easy. Excuse us, please.\r\n\r\nCome on! You want me to stay because of the way you feel about me. Yes. You\'re a great help to us. You\'re a natural leader... No! That\'s not it. Come on. Aahhh - uh huh! Come on. You\'re imagining things. Am I? Then why are you following me? Afraid I was going to leave without giving you a goodbye kiss? I\'d just as soon kiss a Wookiee. I can arrange that. You could use a good kiss!', NULL, NULL, '2019-06-11 01:17:51', '2019-06-11 11:32:29', '2019-06-11 11:32:29'),
(3, 'El titán loco III', 'Historia de un titán III', 'The Empire is still out there. I don\'t think it\'s wise to... No time to discuss this as a committee. I am not a committee! You can\'t make the jump to light-speed in this asteroid field... Sit down, sweetheart. We\'re taking off! Look! I see it, I see it. We\'re doomed! The cave is collapsing. This is no cave. What?\r\n\r\nLaugh it up, fuzz ball. But you didn\'t see us alone in the south passage. She expressed her true feelings for me. My...! Why, you stuck up...half-witted...scruffy-looking...nerf-herder! Who\'s scruffy-looking? I must have hit her pretty close to the mark to get her all riled up like that, huh, kid? Why, I guess you don\'t know everything about women yet? Headquarters personnel, report to command center. Take it easy. Excuse us, please.\r\n\r\nCome on! You want me to stay because of the way you feel about me. Yes. You\'re a great help to us. You\'re a natural leader... No! That\'s not it. Come on. Aahhh - uh huh! Come on. You\'re imagining things. Am I? Then why are you following me? Afraid I was going to leave without giving you a goodbye kiss? I\'d just as soon kiss a Wookiee. I can arrange that. You could use a good kiss!', 'DypIiAu6eqbPSH7qrgdaMejk23e0nX54UWqEyddp.jpeg', NULL, '2019-06-11 01:32:12', '2019-06-11 01:32:12', NULL),
(4, 'Prueba título número 4', 'Lorem ipsum prueba número 4', 'As noted above, soft deleted models will automatically be excluded from query results. However, you may force soft deleted models to appear in a result set using the withTrashed method on the query.', 'NdQsjc9vmDGjIc2Fzd8d4G0F52ofnA2OZh5cMEt1.jpeg', NULL, '2019-06-11 11:35:12', '2019-06-11 11:35:12', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) DEFAULT NULL,
  `genero` varchar(45) NOT NULL,
  `avatar` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `email`, `password`, `genero`, `avatar`) VALUES
(21, 'nacho', 'nacho@dh.com', '$2y$10$/s0CCmLH3vO5.8PXb0MOCeMzlaXFjEbnDqbQYJvpA4lL.6VQH0V3G', 'other', 'ruta de la imagen o nombre del archivo');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `addresses`
--
ALTER TABLE `addresses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
